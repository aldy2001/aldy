<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Contact</title>
</head>
<body>
	<h1>Contac Us</h1>
</body>
</html><?php /**PATH C:\xampp\htdocs\belajar_laravel\resources\views/contact.blade.php ENDPATH**/ ?>